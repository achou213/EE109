void adc_init(void);
unsigned char adc_sample(unsigned char);
